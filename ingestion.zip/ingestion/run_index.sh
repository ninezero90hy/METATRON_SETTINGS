curl -X POST -H 'content-type: application/json' -d @$1 http://localhost:8090/druid/indexer/v1/task
