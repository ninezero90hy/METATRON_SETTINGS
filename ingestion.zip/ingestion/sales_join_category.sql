-- DataSource
INSERT INTO datasource(id, ds_name, ds_engine_name, ds_owner_id, ds_desc, ds_type, ds_conn_type, ds_granularity, ds_status, ds_published, version, created_time, created_by, modified_time, modified_by) values
  ('ds-sales-join-01', 'sales joins category', 'sales_join_category', 'polaris', 'sales join category', 'MASTER', 'ENGINE', 'DAY', 'ENABLED', true, 1.0, NOW(), 'polaris',  NOW(), 'polaris');
INSERT INTO field(id, ds_id, seq, field_name, field_type, bi_type, field_format) values
  (10038001, 'ds-sales-join-01', 0, 'time', 'TIMESTAMP', 'TIMESTAMP', 'yyyy-MM-dd'),
  (10038002, 'ds-sales-join-01', 2, 'cat', 'TEXT', 'DIMENSION', null ),
  (10038003, 'ds-sales-join-01', 3, 'value', 'TEXT', 'DIMENSION', null ),
  (10038004, 'ds-sales-join-01', 4, 'abbr', 'TEXT', 'DIMENSION', null ),
  (10038005, 'ds-sales-join-01', 5, 'count', 'DOUBLE', 'MEASURE', null );
INSERT INTO datasource(id, ds_name, ds_engine_name, ds_owner_id, ds_desc, ds_type, ds_conn_type, ds_granularity, ds_status, ds_published, version, created_time, created_by, modified_time, modified_by) values
  ('ds-sales-join-02', 'sales multi joins', 'sales_multi_join_category', 'polaris', 'sales multi join category', 'MASTER', 'ENGINE', 'DAY', 'ENABLED', true, 1.0, NOW(), 'polaris',  NOW(), 'polaris');
INSERT INTO field(id, ds_id, seq, field_name, field_type, bi_type, field_format) values
  (10039001, 'ds-sales-join-02', 0, 'time', 'TIMESTAMP', 'TIMESTAMP', 'yyyy-MM-dd'),
  (10039002, 'ds-sales-join-02', 1, 'cat', 'TEXT', 'DIMENSION', null ),
  (10039003, 'ds-sales-join-02', 2, 'subcat', 'TEXT', 'DIMENSION', null ),
  (10039004, 'ds-sales-join-02', 3, 'value', 'TEXT', 'DIMENSION', null ),
  (10039005, 'ds-sales-join-02', 4, 'subvalue', 'TEXT', 'DIMENSION', null ),
  (10039006, 'ds-sales-join-02', 5, 'abbr', 'TEXT', 'DIMENSION', null ),
  (10039007, 'ds-sales-join-02', 6, 'count', 'DOUBLE', 'MEASURE', null );
INSERT INTO datasource(id, ds_name, ds_engine_name, ds_owner_id, ds_desc, ds_type, ds_conn_type, ds_granularity, ds_status, ds_published, version, created_time, created_by, modified_time, modified_by) values
  ('ds-sales-join-03', 'sales joins region', 'sales_join_region', 'polaris', 'sales join region', 'MASTER', 'ENGINE', 'DAY', 'ENABLED', true, 1.0, NOW(), 'polaris',  NOW(), 'polaris');
INSERT INTO field(id, ds_id, seq, field_name, field_type, bi_type, field_format) values
  (10040001, 'ds-sales-join-03', 0, 'time', 'TIMESTAMP', 'TIMESTAMP', 'yyyy-MM-dd'),
  (10040002, 'ds-sales-join-03', 1, 'region', 'TEXT', 'DIMENSION', null ),
  (10040003, 'ds-sales-join-03', 2, 'value', 'TEXT', 'DIMENSION', null ),
  (10040004, 'ds-sales-join-03', 3, 'count', 'DOUBLE', 'MEASURE', null );
COMMIT;
