./bin/single.sh zookeeper broker coordinator historical middleManager overlord
