echo "Stop druid"
ps -ef | grep io.druid.cli.Main | grep -v grep | awk '{print $2}' | xargs kill -9
ps -ef | grep io.druid.cli.ServerRunnable | grep -v grep | awk '{print $2}' | xargs kill

