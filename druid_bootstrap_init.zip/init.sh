#!/bin/sh

if [ $# -ne 1 ]; then
    echo "Usage: $0 file_to_distribute"
    exit -1
fi

DRUID_VERSION="0.9.1-SNAPSHOT"
BOOTSTRAP_DIR="./druid_bootstrap_local"
BASE_DIR=`pwd`
RELEASE_ROOT_DIR="./$1"

echo "Start initializing $1"

set -x
set -e

echo "copy conf directory"
rm -rf "${RELEASE_ROOT_DIR}/conf"
cp -a ${BOOTSTRAP_DIR}/conf ${RELEASE_ROOT_DIR}/

# druid-hdfs-storage-0.9.1-SNAPSHOT.jar
#echo "delete hive related jars in ./lib"
#rm -f ${RELEASE_ROOT_DIR}/lib/hive*.jar
#rm -f ${RELEASE_ROOT_DIR}/lib/libthrift*.jar

#echo "copy hadoop libraries"
#cp ${RELEASE_ROOT_DIR}/extensions/druid-hdfs-storage/druid-hdfs-storage-${DRUID_VERSION}.jar ${BOOTSTRAP_DIR}/tmp
#rm -f ${RELEASE_ROOT_DIR}/extensions/druid-hdfs-storage/*
#cp ${BOOTSTRAP_DIR}/hadoop-2.6.0/* ${RELEASE_ROOT_DIR}/extensions/druid-hdfs-storage/
#cp ${BOOTSTRAP_DIR}/tmp/druid-hdfs-storage-${DRUID_VERSION}.jar ${RELEASE_ROOT_DIR}/extensions/druid-hdfs-storage/

#echo "copy extensions/druid-orc-extensions/hive-exec-2.0.0.jar"
#cp ${BOOTSTRAP_DIR}/extensions_lib/druid-orc-extensions/hive-exec-2.0.0.jar ${RELEASE_ROOT_DIR}/extensions/druid-orc-extensions/

#echo "copy extensions/druid-hdfs-storage/aircompressor.jar, hive-storage-api.jar, orc-core.jar"
#cp ${BOOTSTRAP_DIR}/extensions_lib/druid-hdfs-storage/* ${RELEASE_ROOT_DIR}/extensions/druid-hdfs-storage/

#echo "copy hadoop libraries to extensions/druid-jdbc-firehose"
#cp ${BOOTSTRAP_DIR}/hadoop-2.6.0/* ${RELEASE_ROOT_DIR}/extensions/druid-jdbc-firehose/

echo "copy lib/*.jar"
cp ${BOOTSTRAP_DIR}/lib/* ${RELEASE_ROOT_DIR}/lib/

echo "copy initial var directory"
cp -R ${BOOTSTRAP_DIR}/var ${RELEASE_ROOT_DIR}/

echo "copy empty log directory"
cp -R ${BOOTSTRAP_DIR}/log ${RELEASE_ROOT_DIR}/

echo "copy scripts/*"
cp -R ${BOOTSTRAP_DIR}/scripts/* ${RELEASE_ROOT_DIR}/

#rm -f ${BOOTSTRAP_DIR}/tmp/*

set +x
set +e

rm -rf druid; ln -s ${BASE_DIR}/$1 druid

echo "Finish initializing $1"
