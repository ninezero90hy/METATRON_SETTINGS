SELECT 'Upgrading MetaStore schema from 0.7.0 to 0.8.0';
\i 008-HIVE-2246.postgres.sql;
\i 009-HIVE-2215.postgres.sql;
SELECT 'Finished upgrading MetaStore schema from 0.7.0 to 0.8.0';
